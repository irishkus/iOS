//
//  MyNewsColCell.swift
//  VK_SolovievaIrina
//
//  Created by Ирина on 20.01.2019.
//  Copyright © 2019 Ирина. All rights reserved.
//

import UIKit

class MyNewsColCell: UICollectionViewCell {

    @IBOutlet weak var FotoNews: UIImageView!
    @IBOutlet weak var fotosNews: MyNewsCollectionView!
    // @IBOutlet weak var imageNews: UIImageView!
 //   @IBOutlet weak var imageNews: UIImageView!
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }

}
