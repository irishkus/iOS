//
//  class WeekDayPicker: UIControl {  } LetterAlphabetPicker.swift
//  VK_SolovievaIrina
//
//  Created by Ирина on 09.01.2019.
//  Copyright © 2019 Ирина. All rights reserved.
//

import UIKit

class class_WeekDayPicker__UIControl______LetterAlphabetPicker: UIControl {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
