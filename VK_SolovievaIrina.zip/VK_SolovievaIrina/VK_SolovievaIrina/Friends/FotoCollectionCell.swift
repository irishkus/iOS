//
//  FotoCollectionCell.swift
//  VK_SolovievaIrina
//
//  Created by Ирина on 24.12.2018.
//  Copyright © 2018 Ирина. All rights reserved.
//

import UIKit

class FotoCollectionCell: UICollectionViewCell {
    @IBOutlet weak var allFoto: UIImageView!
    
//    @objc func tap(gesture: UITapGestureRecognizer) {
//        print("1")
//        if gesture.state == .began {
//            animateAuthButton()
//        }
//    }
//    
//    func animateAuthButton() {
//        print("2")
//    let animation = CASpringAnimation(keyPath: "transform.scale")
//    animation.fromValue = 0
//    animation.toValue = 1
//    animation.stiffness = 200
//    animation.mass = 2
//    animation.duration = 2
//    animation.beginTime = CACurrentMediaTime() + 1
//    
//    self.allFoto.layer.add(animation, forKey: nil)
//    }

}
