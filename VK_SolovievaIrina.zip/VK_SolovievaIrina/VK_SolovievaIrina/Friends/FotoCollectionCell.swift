//
//  FotoCollectionCell.swift
//  VK_SolovievaIrina
//
//  Created by Ирина on 24.12.2018.
//  Copyright © 2018 Ирина. All rights reserved.
//

import UIKit

class FotoCollectionCell: UICollectionViewCell {
    @IBOutlet weak var allFoto: UIImageView!
}
